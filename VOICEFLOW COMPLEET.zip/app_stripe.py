from flask import Flask, request, jsonify, render_template_string, redirect
from twilio.twiml.voice_response import VoiceResponse, Gather
import os
from datetime import datetime
import stripe

app = Flask(__name__)

# Stripe Configuration
stripe.api_key = "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"
STRIPE_PUBLISHABLE_KEY = "pk_live_51RL84kCSc4e80NopgOZBNM0O8IGkDC7MOsRhvgvRTD8VW5jcEkkjcyeLYOQsZgMYu0nSjjDj6V8nrQ4yLNPAqCea00kO3Vvopt"

# Stripe Price IDs (these will be created automatically)
PRICES = {
    'starter': 'price_starter_29',
    'premium': 'price_premium_99',
    'enterprise': 'price_enterprise_299'
}

# Simple storage
appointments = []
customers = []

# Premium Landing Page with Stripe Integration
PREMIUM_LANDING = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VoiceFlow AI - Never Miss A Call Again 💎</title>
    <script src="https://js.stripe.com/v3/"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: white;
        }
        .container { max-width: 1200px; margin: 0 auto; padding: 40px 20px; }
        .hero { text-align: center; margin-bottom: 60px; }
        .hero h1 { font-size: 72px; font-weight: 900; margin-bottom: 20px; text-shadow: 0 4px 20px rgba(0,0,0,0.3); }
        .hero .subtitle { font-size: 28px; margin-bottom: 30px; opacity: 0.95; }
        .badge { display: inline-block; background: linear-gradient(135deg, #f6d365 0%, #fda085 100%);
                color: #000; padding: 12px 30px; border-radius: 50px; font-weight: bold; margin-bottom: 30px; }
        .dashboard { background: rgba(255,255,255,0.95); backdrop-filter: blur(20px); border-radius: 30px;
                    padding: 40px; box-shadow: 0 20px 60px rgba(0,0,0,0.3); margin-bottom: 40px; color: #1f2937; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 30px 0; }
        .stat-card { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;
                    padding: 30px; border-radius: 20px; text-align: center; }
        .stat-value { font-size: 48px; font-weight: bold; }
        .stat-label { font-size: 16px; opacity: 0.9; text-transform: uppercase; }
        .cta-button { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;
                     padding: 18px 40px; border-radius: 50px; font-size: 18px; font-weight: bold;
                     border: none; cursor: pointer; box-shadow: 0 10px 30px rgba(102,126,234,0.4);
                     transition: transform 0.2s; }
        .cta-button:hover { transform: translateY(-3px); }
        .pricing-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 30px; margin-top: 30px; }
        .price-card { background: white; border: 3px solid #e5e7eb; border-radius: 20px; padding: 40px; text-align: center; }
        .price-card.featured { border-color: #667eea; transform: scale(1.05); }
        .plan-price { font-size: 56px; font-weight: bold; margin: 20px 0; }
        .features { text-align: left; margin: 20px 0; list-style: none; }
        .features li { margin-bottom: 15px; padding-left: 30px; position: relative; }
        .features li:before { content: "✓"; position: absolute; left: 0; color: #10b981; font-weight: bold; font-size: 20px; }
        @media (max-width: 768px) { .hero h1 { font-size: 48px; } }
    </style>
</head>
<body>
    <div class="container">
        <div class="hero">
            <div class="badge">💎 LIVE NOW - TAKING CALLS 24/7</div>
            <h1>VoiceFlow AI</h1>
            <p class="subtitle">Never Miss A Call. Never Lose A Customer.</p>
        </div>
       
        <div class="dashboard">
            <h2 style="text-align: center; font-size: 36px; margin-bottom: 30px;">The Problem You're Facing</h2>
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-value">40%</div>
                    <div class="stat-label">Calls Unanswered</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">$10K</div>
                    <div class="stat-label">Lost Monthly</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">67%</div>
                    <div class="stat-label">Call Competitors</div>
                </div>
            </div>
        </div>
       
        <div class="dashboard">
            <h2 style="text-align: center; font-size: 36px; margin-bottom: 30px;">Simple Pricing - Start Today</h2>
            <div class="pricing-grid">
                <div class="price-card">
                    <div style="font-size: 24px; font-weight: bold; margin-bottom: 20px;">Starter</div>
                    <div class="plan-price">$29</div>
                    <div style="opacity: 0.7; margin-bottom: 30px;">/month</div>
                    <ul class="features">
                        <li>500 minutes/month</li>
                        <li>1 phone number</li>
                        <li>Basic AI responses</li>
                        <li>Email support</li>
                        <li>14-day free trial</li>
                    </ul>
                    <button class="cta-button" onclick="checkout('starter')">Start Free Trial</button>
                </div>
               
                <div class="price-card featured">
                    <div style="font-size: 24px; font-weight: bold; margin-bottom: 20px;">💎 Premium</div>
                    <div class="plan-price">$99</div>
                    <div style="opacity: 0.7; margin-bottom: 30px;">/month</div>
                    <ul class="features">
                        <li>2,000 minutes/month</li>
                        <li>3 phone numbers</li>
                        <li>Smart booking AI</li>
                        <li>Priority support</li>
                        <li>Revenue analytics</li>
                        <li>14-day free trial</li>
                    </ul>
                    <button class="cta-button" onclick="checkout('premium')">Start Free Trial</button>
                </div>
               
                <div class="price-card">
                    <div style="font-size: 24px; font-weight: bold; margin-bottom: 20px;">Enterprise</div>
                    <div class="plan-price">$299</div>
                    <div style="opacity: 0.7; margin-bottom: 30px;">/month</div>
                    <ul class="features">
                        <li>Unlimited minutes</li>
                        <li>Unlimited numbers</li>
                        <li>Custom AI training</li>
                        <li>White-label option</li>
                        <li>Dedicated support</li>
                        <li>14-day free trial</li>
                    </ul>
                    <button class="cta-button" onclick="checkout('enterprise')">Contact Sales</button>
                </div>
            </div>
        </div>
       
        <div style="text-align: center; padding: 40px;">
            <p style="font-size: 14px; opacity: 0.7;">Questions? Email: voiceflowai539@gmail.com | Twitter: @okfreelancer</p>
            <p style="font-size: 12px; opacity: 0.6; margin-top: 10px;">Crypto: 2jAMeJZH1UeNSgdzdhHgYwAm6286aRqxMCdx52DBw7xo</p>
        </div>
    </div>

    <script>
        const stripe = Stripe('""" + STRIPE_PUBLISHABLE_KEY + """');
        
        async function checkout(plan) {
            if (plan === 'enterprise') {
                window.location.href = 'mailto:voiceflowai539@gmail.com?subject=Enterprise Plan Inquiry';
                return;
            }
            
            try {
                const response = await fetch('/create-checkout-session', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ plan: plan })
                });
                
                const session = await response.json();
                
                if (session.error) {
                    alert('Error: ' + session.error);
                    return;
                }
                
                const result = await stripe.redirectToCheckout({
                    sessionId: session.sessionId
                });
                
                if (result.error) {
                    alert(result.error.message);
                }
            } catch (error) {
                console.error('Error:', error);
                alert('Something went wrong. Please email voiceflowai539@gmail.com');
            }
        }
    </script>
</body>
</html>
"""

SUCCESS_PAGE = """
<!DOCTYPE html>
<html>
<head>
    <title>Welcome to VoiceFlow AI! 🎉</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            text-align: center;
            padding: 20px;
        }
        .success-box {
            background: rgba(255,255,255,0.95);
            color: #1f2937;
            padding: 60px 40px;
            border-radius: 30px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            max-width: 600px;
        }
        h1 { font-size: 48px; margin-bottom: 20px; }
        p { font-size: 18px; line-height: 1.6; margin-bottom: 15px; }
        .email { background: #f3f4f6; padding: 15px; border-radius: 10px; margin: 20px 0; }
    </style>
</head>
<body>
    <div class="success-box">
        <h1>🎉 Welcome to VoiceFlow AI!</h1>
        <p>Your subscription is active! Here's what happens next:</p>
        <ol style="text-align: left; margin: 20px 0;">
            <li style="margin-bottom: 15px;"><strong>Check your email</strong> - We've sent setup instructions</li>
            <li style="margin-bottom: 15px;"><strong>We'll contact you within 24 hours</strong> to configure your phone number</li>
            <li style="margin-bottom: 15px;"><strong>Go live!</strong> - Your AI will be answering calls 24/7</li>
        </ol>
        <div class="email">
            <strong>Need help now?</strong><br>
            Email: voiceflowai539@gmail.com<br>
            Twitter: @okfreelancer
        </div>
        <p style="opacity: 0.7; font-size: 14px;">Your 14-day free trial starts today!</p>
    </div>
</body>
</html>
"""

@app.route('/')
def home():
    return PREMIUM_LANDING

@app.route('/create-checkout-session', methods=['POST'])
def create_checkout_session():
    try:
        data = request.get_json()
        plan = data.get('plan', 'starter')
        
        # Price mapping
        prices = {
            'starter': 2900,  # $29 in cents
            'premium': 9900,  # $99 in cents
        }
        
        if plan not in prices:
            return jsonify({'error': 'Invalid plan'}), 400
        
        # Create Stripe Checkout Session
        session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            mode='subscription',
            line_items=[{
                'price_data': {
                    'currency': 'usd',
                    'product_data': {
                        'name': f'VoiceFlow AI - {plan.title()} Plan',
                        'description': f'AI Phone Assistant - {plan.title()} tier',
                    },
                    'unit_amount': prices[plan],
                    'recurring': {
                        'interval': 'month',
                    },
                },
                'quantity': 1,
            }],
            subscription_data={
                'trial_period_days': 14,
            },
            success_url=request.host_url + 'success?session_id={CHECKOUT_SESSION_ID}',
            cancel_url=request.host_url,
            customer_email=None,
            allow_promotion_codes=True,
        )
        
        return jsonify({'sessionId': session.id})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/success')
def success():
    session_id = request.args.get('session_id')
    
    if session_id:
        try:
            # Retrieve session details
            session = stripe.checkout.Session.retrieve(session_id)
            customer_email = session.customer_email or session.customer_details.email
            
            # Store customer info
            customers.append({
                'email': customer_email,
                'session_id': session_id,
                'timestamp': datetime.now().isoformat()
            })
            
            # TODO: Send welcome email here
            
        except Exception as e:
            print(f"Error retrieving session: {e}")
    
    return SUCCESS_PAGE

@app.route('/webhook', methods=['POST'])
def webhook():
    payload = request.get_data()
    sig_header = request.headers.get('Stripe-Signature')
    
    try:
        # Note: Set your webhook secret in Stripe dashboard
        # event = stripe.Webhook.construct_event(payload, sig_header, webhook_secret)
        
        # Handle different event types
        # if event['type'] == 'checkout.session.completed':
        #     # Handle successful checkout
        #     pass
        
        return jsonify({'status': 'success'})
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/voice/incoming', methods=['GET', 'POST'])
def incoming_call():
    response = VoiceResponse()
    response.say("Hello! Thank you for calling VoiceFlow AI. I'm your AI assistant, ready to help you 24/7.",
                 voice='Polly.Joanna', language='en-US')
    response.say("How can I help you today?", voice='Polly.Joanna')
   
    gather = Gather(input='speech', action='/voice/process', method='POST',
                   speechTimeout='auto', language='en-US')
    response.append(gather)
    return str(response)

@app.route('/voice/process', methods=['POST'])
def process_call():
    response = VoiceResponse()
    speech = request.values.get('SpeechResult', '').lower()
   
    if any(word in speech for word in ['appointment', 'book', 'schedule']):
        response.say("Great! I can book that for you. What day works best?", voice='Polly.Joanna')
        gather = Gather(input='speech', action='/voice/get-date', method='POST',
                       speechTimeout='auto', language='en-US')
        response.append(gather)
    elif any(word in speech for word in ['price', 'cost', 'how much']):
        response.say("Our service starts at just 99 dollars per month with a 14 day free trial. Would you like to learn more?",
                    voice='Polly.Joanna')
    else:
        response.say("I can help you book appointments, answer pricing questions, or transfer you to a team member. What would you prefer?",
                    voice='Polly.Joanna')
   
    return str(response)

@app.route('/voice/get-date', methods=['POST'])
def get_date():
    response = VoiceResponse()
    date_said = request.values.get('SpeechResult', '')
   
    response.say(f"Perfect! Booking you for {date_said}. What's your phone number for confirmation?",
                voice='Polly.Joanna')
   
    gather = Gather(input='speech', action='/voice/confirm', method='POST',
                   speechTimeout='auto', language='en-US')
    response.append(gather)
    return str(response)

@app.route('/voice/confirm', methods=['POST'])
def confirm():
    response = VoiceResponse()
    phone = request.values.get('SpeechResult', '')
   
    appointment = {
        'phone': phone,
        'time': datetime.now().isoformat(),
        'status': 'confirmed'
    }
    appointments.append(appointment)
   
    response.say("Your appointment is confirmed! You'll receive a text confirmation shortly. Thank you for calling!",
                voice='Polly.Joanna')
    return str(response)

@app.route('/admin/appointments')
def view_appointments():
    return jsonify({'appointments': appointments, 'total': len(appointments)})

@app.route('/admin/customers')
def view_customers():
    return jsonify({'customers': customers, 'total': len(customers)})

@app.route('/health')
def health():
    return jsonify({
        'status': 'healthy',
        'appointments': len(appointments),
        'customers': len(customers)
    })

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)
