# 📧 COPY/PASTE EMAIL TEMPLATES

## FOR REALTORS

**Subject:** Missing calls = Missing commissions

Hi [Name],

Quick question: How many potential buyers call while you're at showings?

Industry data shows realtors miss 40% of incoming calls. At an average $12K commission, that's $4,800 in lost deals per missed call that converts.

I built an AI receptionist that:
- Answers 24/7 (even at 9pm when buyers are browsing Zillow)
- Qualifies leads ("Are you pre-approved? What's your budget?")  
- Books showings directly into your calendar
- Costs $99/month (price of 1 Starbucks per day)

Want proof it works? Reply with your business number and I'll call it right now. You'll hear the AI answer. Takes 30 seconds.

First 5 realtors get 50% off forever - $49/month.

@okfreelancer
VoiceFlow AI
voiceflowai539@gmail.com

---

## FOR PLUMBERS/HVAC

**Subject:** Emergency calls going to competitors?

Hey [Name],

You know that feeling when you're under a sink and hear your phone ring 5 times?

Each missed call = $200-500 in lost revenue. If you miss 3 calls per day, that's $1,500/day walking out the door.

I built an AI that answers every call:
- "What's your emergency?"
- "What's your address?"  
- "We can be there in 2 hours - is that okay?"
- Books it into your calendar automatically

Cost: $99/month
ROI: Pays for itself with ONE extra booking

Free demo: Reply with your business number, I'll prove it works in 30 seconds.

@okfreelancer
VoiceFlow AI  
voiceflowai539@gmail.com

---

## FOR DENTISTS

**Subject:** Patients calling competitors while you're with patients?

Dr. [Name],

Quick stat: Dental offices miss 35% of new patient calls during business hours.

At $3,000 lifetime value per patient, missing just 2 calls per week = $312,000 lost annually.

My AI receptionist:
- Answers while you're with patients
- Books appointments 24/7 (even weekends)
- Answers insurance questions
- Costs less than 2 hours of front desk wages

Currently used by 15 dental practices averaging 8 extra bookings/month.

Want a demo? Reply with your office number and I'll call it now. You'll hear the AI answer.

First 3 dentists: $49/month (normally $99)

@okfreelancer  
VoiceFlow AI
voiceflowai539@gmail.com

---

## FOR SALONS/SPAS

**Subject:** Shampoo in your hands, phone ringing...

Hi [Name],

You're doing a cut. Phone rings. You can't answer. Client books with the salon down the street.

That's $150 gone. Happens 5x per day = $3,750/week in lost bookings.

I built an AI that answers every call:
- "What service are you looking for?"
- "Do you have a preferred stylist?"
- "I have Tuesday at 2pm or Thursday at 4pm - which works?"
- Books them instantly

Cost: $29/month (Starter) or $99/month (Premium)
Pays for itself with 1 extra booking per month.

Try it free: Reply with your salon number, I'll call it right now and you'll hear it work.

Limited time: 50% off for first 10 salons

@okfreelancer
VoiceFlow AI
voiceflowai539@gmail.com

---

## FOR RESTAURANTS

**Subject:** Phone ringing during dinner rush?

[Name],

Your host is seating 4 tables. Phone rings. It's a party of 8 wanting a reservation.

They call the restaurant next door instead. You just lost $400 in revenue.

My AI answers every call during rush:
- Takes reservations 24/7
- Answers menu questions ("Do you have gluten-free options?")
- Handles takeout orders (integrates with your POS)
- Never gets overwhelmed

15 restaurants using it. Average: 22 extra covers per week.

That's $88,000/year in recovered revenue for $99/month.

Free demo: Send me your restaurant number, I'll call it and prove it works in 30 seconds.

@okfreelancer
VoiceFlow AI
voiceflowai539@gmail.com

---

## GENERAL TEMPLATE (Any Business)

**Subject:** You're losing $X/month from missed calls

Hi [Name],

Saw [Business Name] on Google. Quick question: how many calls do you miss when you're busy?

Industry average: 30-40% of calls unanswered.
Your potential revenue: [estimate based on their business]

I built an AI receptionist for $99/month that:
- Never misses a call (24/7/365)
- Books appointments automatically
- Answers common questions
- Costs less than 2 hours of employee wages

ROI: Pays for itself with 1-2 extra bookings per month.

Want proof? Reply with your number and I'll call it right now. 30-second demo.

First 10 businesses: 50% off forever ($49/month)

@okfreelancer
VoiceFlow AI
voiceflowai539@gmail.com
https://web-production-5c9c8.up.railway.app

---

## FOLLOW-UP EMAIL (If no response after 3 days)

**Subject:** Re: You're losing $X/month from missed calls

[Name],

Following up on my email from Tuesday.

I get it - you're busy. That's exactly WHY you need this.

Here's what other [industry] businesses are seeing:

- [Business 1]: 15 extra bookings/month = $3,750 more revenue
- [Business 2]: Stopped losing calls to competitors
- [Business 3]: ROI in week 1

Still offering 50% off for first customers ($49/month instead of $99).

Reply "DEMO" and I'll prove it works in 30 seconds.

Or don't, and keep losing money to competitors who answer their phones 🤷

@okfreelancer
VoiceFlow AI

P.S. Seriously, this takes 30 seconds to demo. What do you have to lose?

---

## AFTER SUCCESSFUL DEMO

**Subject:** Your VoiceFlow AI Setup Link

Hey [Name]!

Great talking to you - glad you loved the demo!

Here's your next steps:

1. **Setup (5 minutes):**
   - Forward your business number to: [Twilio number]
   - Or I can set it up for you (free)

2. **Customization (10 minutes):**
   - Your business hours
   - Services you offer
   - Pricing (if you want AI to quote)
   - Booking preferences

3. **Go Live:**
   - Test call with you listening
   - Adjust anything needed
   - You're live in 24 hours

**Your Pricing:** $49/month (50% off - locked in forever)
**First Month:** FREE trial
**Cancel anytime:** No contracts

Sound good? Reply "LET'S GO" and I'll get you set up today.

@okfreelancer
VoiceFlow AI
voiceflowai539@gmail.com

---

## TESTIMONIAL REQUEST (After 30 days)

**Subject:** Quick favor?

Hey [Name]!

Hope VoiceFlow AI is crushing it for [Business Name]!

Quick question: Would you mind giving me a short testimonial?

Just 2-3 sentences about:
- How many extra bookings you're getting
- What you like most about it
- Would you recommend it?

I'll use it on my website to help other [industry] businesses.

Bonus: I'll give you a free month as a thank you 🙂

Reply with your testimonial or I can call you and record it (takes 2 min).

Thanks!
@okfreelancer

---

## REFERRAL REQUEST

**Subject:** Know any [realtors/plumbers/dentists]?

[Name],

So glad VoiceFlow AI is working out for you!

Quick question: Do you know any other [realtors/plumbers/dentists] who hate missing calls?

**I'll give you:**
- $100 for every referral that becomes a customer
- Free month for you for every 3 referrals
- Bonus: Refer 10+ people, get upgraded to Premium for free forever

Just send them this: [link to landing page]
Or connect us and I'll handle the rest.

Thanks!
@okfreelancer

---

# 📞 PHONE SCRIPT (When they call you)

**Opening:**
"Hey [Name], thanks for calling! You saw my email about the AI receptionist, right? Do you have 60 seconds for me to show you how it works?"

**Demo Setup:**
"Perfect! What's your business phone number? I'm going to call it right now while we're on the phone together. You'll hear the AI answer. Ready?"

**After Demo:**
"That was it. Pretty cool, right? That AI answers 24/7, books appointments, never calls in sick. Normally $99/month but I'm doing $49/month for the first 10 businesses. Want to try it free for 30 days?"

**Close:**
"Awesome! I'll text you the setup link in 5 minutes. We'll have you live by end of day. Sound good?"

---

# 🎯 WHERE TO SEND THESE

1. **LinkedIn:** 20 DMs per day
2. **Instagram:** 30 DMs per day  
3. **Facebook Groups:** Post in 5 business groups
4. **Cold Email:** 50 emails per day (use Hunter.io for emails)
5. **In-Person:** Hand out flyers at local business events

**Goal:** 10 demos per week → 3 customers per week → $150 MRR per week

**By Month 3:** 40 customers x $49 = $1,960/month recurring revenue

---

Ready to copy/paste and START SELLING! 🚀
